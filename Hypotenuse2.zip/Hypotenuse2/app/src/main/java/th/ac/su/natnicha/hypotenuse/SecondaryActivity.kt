package th.ac.su.natnicha.hypotenuse

import android.app.Activity
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class SecondaryActivity : AppCompatActivity() {
    var logA:Double? = null
    var logB:Double? = null
    var logC:Double? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_secondary)

        logA = intent.getDoubleExtra("logA",1.0)
        logB = intent.getDoubleExtra("logB",1.0)

        var ok = findViewById<Button>(R.id.ok)
        var showB = findViewById<TextView>(R.id.showB)
        var showA = findViewById<TextView>(R.id.showA)
        var showC = findViewById<TextView>(R.id.showC)

        showB.text = logB.toString()
        showA.text = logA.toString()
        logC = (logA!! * logA!!)+(logB!! * logB!!)
        showC.text = Math.sqrt(logC!!).toString();
        ok.setOnClickListener {
            setResult(Activity.RESULT_OK,intent)
            finish()

        }

    }
}